const socket = io('http://localhost:3000');
let currentRoom = null;
let isHost = false;

document.getElementById("offlineModeBtn").onclick = () => {
  document.getElementById("modeSelect").style.display = "none";
};
document.getElementById("onlineModeBtn").onclick = () => {
  document.getElementById("modeSelect").style.display = "none";
  document.getElementById("onlineSection").style.display = "block";
};

document.getElementById("createRoomBtn").onclick = () => {
  const name = document.getElementById("onlineNameInput").value;
  if (name) socket.emit("createRoom", { name });
};

document.getElementById("joinRoomBtn").onclick = () => {
  const name = document.getElementById("onlineNameInput").value;
  const code = document.getElementById("joinCodeInput").value;
  if (name && code) socket.emit("joinRoom", { code, name });
};

document.getElementById("onlineStartBtn").onclick = () => {
  if (currentRoom) socket.emit("startGame", { code: currentRoom });
};

document.getElementById("resetBtn").onclick = () => {
  if (currentRoom) socket.emit("resetGame", { code: currentRoom });
};

socket.on("roomCreated", ({ code }) => {
  currentRoom = code;
  isHost = true;
  document.getElementById("roomCodeDisplay").textContent = code;
  document.getElementById("roomInfo").style.display = "block";
  document.getElementById("onlineStartBtn").style.display = "inline-block";
});

socket.on("roomJoined", ({ code, players }) => {
  currentRoom = code;
  isHost = false;
  document.getElementById("roomCodeDisplay").textContent = code;
  document.getElementById("roomInfo").style.display = "block";
  document.getElementById("onlineStartBtn").style.display = "none";
  updatePlayerList(players);
});

socket.on("playerListUpdate", (players) => {
  updatePlayerList(players);
});

socket.on("assignment", (text) => {
  const box = document.getElementById("assignmentDisplay");
  const txt = document.getElementById("assignmentText");
  if (text) {
    txt.textContent = text === "IMPOSTOR" ? "IMPOSTOR" : `Dein Wort: ${text}`;
    box.style.display = "block";
    if (isHost) document.getElementById("resetBtn").style.display = "inline-block";
  } else {
    box.style.display = "none";
    txt.textContent = "";
    document.getElementById("resetBtn").style.display = "none";
  }
});

function updatePlayerList(players) {
  const list = document.getElementById("onlinePlayerList");
  list.innerHTML = "";
  players.forEach(p => {
    const li = document.createElement("li");
    li.textContent = p;
    list.appendChild(li);
  });
}
