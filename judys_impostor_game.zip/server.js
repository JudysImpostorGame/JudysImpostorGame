const io = require('socket.io')(3000, {
  cors: { origin: '*' }
});
const rooms = {};

function getRandomCode() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  return Array.from({length: 4}, () => chars[Math.floor(Math.random() * chars.length)]).join('');
}

io.on('connection', socket => {
  socket.on('createRoom', ({ name }) => {
    const code = getRandomCode();
    rooms[code] = { host: socket.id, players: {}, assignments: {} };
    rooms[code].players[socket.id] = name;
    socket.join(code);
    socket.emit('roomCreated', { code });
    io.to(code).emit('playerListUpdate', Object.values(rooms[code].players));
  });

  socket.on('joinRoom', ({ code, name }) => {
    const room = rooms[code];
    if (!room) return;
    room.players[socket.id] = name;
    socket.join(code);
    socket.emit('roomJoined', { code, players: Object.values(room.players) });
    io.to(code).emit('playerListUpdate', Object.values(room.players));
  });

  socket.on('startGame', ({ code }) => {
    const room = rooms[code];
    if (!room) return;
    const playerIds = Object.keys(room.players);
    const impostors = new Set();
    while (impostors.size < 1 && impostors.size < playerIds.length - 1) {
      impostors.add(playerIds[Math.floor(Math.random() * playerIds.length)]);
    }
    const word = 'Löwe'; // Beispielwort
    playerIds.forEach(pid => {
      const role = impostors.has(pid) ? 'IMPOSTOR' : word;
      io.to(pid).emit('assignment', role);
    });
  });

  socket.on('resetGame', ({ code }) => {
    const room = rooms[code];
    if (room) {
      room.assignments = {};
      io.to(code).emit('assignment', null);
    }
  });

  socket.on('disconnecting', () => {
    for (const code in rooms) {
      if (rooms[code].players[socket.id]) {
        delete rooms[code].players[socket.id];
        io.to(code).emit('playerListUpdate', Object.values(rooms[code].players));
        if (Object.keys(rooms[code].players).length === 0) delete rooms[code];
      }
    }
  });
});
